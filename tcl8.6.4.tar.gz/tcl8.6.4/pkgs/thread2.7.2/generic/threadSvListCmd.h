/*
 * Copyright (c) 2002 by Zoran Vasiljevic.
 *
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 * ---------------------------------------------------------------------------
 */

#ifndef _SV_LIST_H_
#define _SV_LIST_H_

MODULE_SCOPE void Sv_RegisterListCommands();

#endif /* _SV_LIST_H_ */

/* EOF $RCSfile: threadSvListCmd.h,v $ */

/* Emacs Setup Variables */
/* Local Variables:      */
/* mode: C               */
/* indent-tabs-mode: nil */
/* c-basic-offset: 4     */
/* End:                  */

